# Class CCache
 
 Cache helper for default laravel cache class
 
#Installation
Require this package in your `composer.json` and update composer.
 
```php

"kharanenka/laravel-cache-helper": "1.0.*"

```