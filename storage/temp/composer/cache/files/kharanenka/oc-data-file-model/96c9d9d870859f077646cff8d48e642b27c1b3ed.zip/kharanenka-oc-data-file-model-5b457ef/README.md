# Trait DataFileModel
 
 Trait helps to get attached to the model file data
 
#Installation
Require this package in your `composer.json` and update composer.
 
```php

"kharanenka/oc-data-file-model": "1.*"

```