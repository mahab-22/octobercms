<?php namespace Lovata\Shopaholic\Classes\Store;

use Lovata\Toolbox\Classes\Store\AbstractListStore;

use Lovata\Shopaholic\Classes\Store\Offer\ActiveListStore;
use Lovata\Shopaholic\Classes\Store\Offer\SortingListStore;
use Lovata\Shopaholic\Classes\Store\Offer\ListBySiteStore;

/**
 * Class OfferListStore
 * @package Lovata\Shopaholic\Classes\Store
 * @author  Andrey Kharanenka, a.khoronenko@lovata.com, LOVATA Group
 *
 * @property ActiveListStore  $active
 * @property SortingListStore $sorting
 * @property ListBySiteStore    $site
 */
class OfferListStore extends AbstractListStore
{
    const SORT_NO = 'no';
    const SORT_PRICE_ASC = 'price|asc';
    const SORT_PRICE_DESC = 'price|desc';
    const SORT_NEW = 'new';

    protected static $instance;

    /**
     * Init store method
     */
    protected function init()
    {
        $this->addToStoreList('sorting', SortingListStore::class);
        $this->addToStoreList('active', ActiveListStore::class);
        $this->addToStoreList('site', ListBySiteStore::class);
    }
}
